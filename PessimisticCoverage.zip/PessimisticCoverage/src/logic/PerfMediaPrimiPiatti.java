package logic;

public class PerfMediaPrimiPiatti {

	public double perfectMedia(double[] prezzi) {
		int count=0;					// Conteggio dei piatti validi (il cui prezzo e' positivo)
		double sum=0.0;
		for(int i=0;i<prezzi.length;i++) {
			if(prezzi[i]>0) {
				count++;
				sum=sum+prezzi[i];
			}
		}
		if(count>0) return sum/count;
		else return 0;
	}
	
}
