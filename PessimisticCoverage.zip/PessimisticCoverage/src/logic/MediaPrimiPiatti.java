package logic;

public class MediaPrimiPiatti {
	
	private PerfMediaPrimiPiatti pmpp;
	private double result;
	
	public MediaPrimiPiatti() {
		this.pmpp = new PerfMediaPrimiPiatti();
	}
	
	public double media(double[] prezzi) {
		double x = this.pmpp.perfectMedia(prezzi);		// perfMedia
		x=x*100;
		long roundVal = Math.round(x);					// Arrotondamento alla seconda cifra dopo la virgola
		this.result = roundVal/100.0;
		return this.result;
	}
	
}
