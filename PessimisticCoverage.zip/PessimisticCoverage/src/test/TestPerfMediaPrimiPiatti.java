package test;

import logic.PerfMediaPrimiPiatti;
import org.junit.Test;
import static org.junit.Assert.*;

public class TestPerfMediaPrimiPiatti {

	@Test
	public void testPerfectMedia1() {
		double[] arrayPrezzi = new double[2];
		arrayPrezzi[0] = 12.74;
		arrayPrezzi[1] = 15.29;
		PerfMediaPrimiPiatti p = new PerfMediaPrimiPiatti();
		double output = p.perfectMedia(arrayPrezzi);
		assertEquals(14.02, output, 0.0);
	}
	
	@Test
	public void testPerfectMedia2() {
		double[] arrayPrezzi = new double[2];
		arrayPrezzi[0] = 0.0;
		arrayPrezzi[1] = -1.15;
		PerfMediaPrimiPiatti p = new PerfMediaPrimiPiatti();
		double output = p.perfectMedia(arrayPrezzi);
		assertEquals(0.0, output, 0.0);
	}
	
}
