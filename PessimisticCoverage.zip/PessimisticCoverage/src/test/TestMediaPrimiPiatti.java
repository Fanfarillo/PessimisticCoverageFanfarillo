package test;

import logic.MediaPrimiPiatti;
import org.junit.Test;
import static org.junit.Assert.*;

public class TestMediaPrimiPiatti {
	
	@Test
	public void testMedia() {
		double[] arrayPrezzi = new double[2];
		arrayPrezzi[0] = 13.25;
		arrayPrezzi[1] = 8.42;
		MediaPrimiPiatti p = new MediaPrimiPiatti();
		double output = p.media(arrayPrezzi);
		assertEquals(10.84, output, 0.0);
	}	
	
}
